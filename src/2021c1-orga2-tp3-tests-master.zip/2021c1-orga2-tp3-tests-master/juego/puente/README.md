# Test de Puentes

Este test muestra a un lemming tratando de crear puentes por lugares de agua.
El lemming comienza yendo para arriba, luego a la derecha, despues abajo, y
luego a la izquierda. Tratando de crear un puente cada vez que se encuentra con
agua. Finalmente, el lemming se encuentra con una pared, trata de crear un
puente pero sigue sin poder pasar.

La condicion de exito es que se creen todos los puentes sobre la parte
izquierda de la pantalla, y que no se rompa la pared.
