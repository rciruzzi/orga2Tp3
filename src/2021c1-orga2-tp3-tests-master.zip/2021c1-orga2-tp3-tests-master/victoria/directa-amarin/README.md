# Test de Victoria Simple Amarin

Este test consiste en un mapa vacio. Los lemmings de Amarin se mueven hacia la derecha hasta el final.
Los lemmings de Betarote se quedan quietos al comienzo.

Gana Amarin.
