# Test de Victoria.

Este test consiste en un mapa que tiene paredes y lagos. Las tareas Amarin y
Betarote van a ir a derecho hasta el objetivo, sin importar que haya en el medio..

En caso de que haya una pared, explotaran, y si hay un lago, se sacrificaran para crear un puente.

Una vez que terminen de despejar todos los obstaculos en el camino, llegaran al final y finalizara el juego.
