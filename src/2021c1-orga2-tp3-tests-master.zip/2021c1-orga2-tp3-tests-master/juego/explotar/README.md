# Test de Explosiones

Este test muestra a los lemmings de Amalin explotando paredes.  Se tiene que
ver al lemming de Amalin explotar la linea de pared que está entre dos lagos en
el medio. Se tiene que cruzar con lemmings betarote y explotarlos también para
hacerse paso.

Al final, hay un lago, que el lemming Amalin no puede explotar.

La condición de éxito es que el Lemming Amarin rompa todas las paredes de su
línea, elimine al lemming Betarote, y no pase por encima del agua.
