# Test de Victoria Simple Betarote

Este test consiste en un mapa vacio. Los lemmings de Betarote se mueven hacia la izquierda hasta el final.
Los lemmings de Amarin se quedan quietos al comienzo.

Gana Betarote.
