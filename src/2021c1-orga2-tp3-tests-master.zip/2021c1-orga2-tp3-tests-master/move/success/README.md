# Test de Movimientos.

Este test consiste en un laberinto con paredes y lagos. Las tareas de Amarin
tratan de desplazarse por el laberinto. 

Deberías ver a las tareas de Amarin lentamente ir por el laberinto, respetando sus bordes.

Para testear, puede ser util aumentar la frecuencia con la que se invocan Lemmings.
